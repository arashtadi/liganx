"""Job submission and retrieval endpoints."""

import re
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse
from sqlmodel import Session, select

from ..db import get_session
from ..models import Compound, DockingResult, Job, JobStatus
from ..schemas import (
    CompoundOut,
    DockingResultOut,
    JobCreate,
    JobOut,
)
from ..services.rate_limit import JOBS_LIMIT
from ..services.runner import run_job_in_background

# Same shape used in structures.py: variant must look like "WT" or "T790M"
# style. URL-controlled values get baked into a path lookup, so we validate
# format first and confine the resolved path to POSE_CACHE.
_VARIANT_RE = re.compile(r"^(WT|[A-Za-z][0-9]+[A-Za-z]([+_][A-Za-z0-9]+)*(del|ins[A-Za-z]+)?)$")

router = APIRouter(prefix="/jobs", tags=["jobs"])


def _resolve_job(session: Session, key: str) -> Job | None:
    """Resolve either a legacy integer job ID or a public share_id to a Job.

    URLs the frontend creates use `share_id` (random base64url token); URLs in
    bookmarks or older tabs may use the integer primary key. Try integer first
    only when the path looks like one — short numeric strings — to avoid a
    spurious DB hit on every share_id.
    """
    if key.isdigit() and len(key) <= 9:
        job = session.get(Job, int(key))
        if job:
            return job
    return session.exec(select(Job).where(Job.share_id == key)).first()


def _to_out(job: Job) -> JobOut:
    # ADMET is computed lazily here (not at job submit) so any SMILES that
    # snuck in before the descriptor module shipped still gets enriched on
    # next read. compute_admet is LRU-cached by SMILES so the second job
    # using the same compound costs ~0ms.
    return JobOut(
        id=job.id,
        share_id=job.share_id,
        pdb_id=job.pdb_id,
        chain=job.chain,
        uniprot_id=job.uniprot_id,
        mutations=[m for m in job.mutations.split(",") if m],
        status=job.status,
        error_message=job.error_message,
        created_at=job.created_at,
        updated_at=job.updated_at,
        exhaustiveness=job.exhaustiveness,
        include_wt=job.include_wt,
        compounds=[
            CompoundOut(id=c.id, name=c.name, smiles=c.smiles, admet=_admet_for(c.smiles))
            for c in job.compounds
        ],
        results=[
            DockingResultOut(
                compound_id=r.compound_id,
                variant=r.variant,
                best_score=r.best_score,
                pose_uri=r.pose_uri,
                extra=r.extra,
            )
            for r in job.results
        ],
        pdb_quality=_pdb_quality_for(job.pdb_id, job.chain),
    )


def _admet_for(smiles: str) -> dict | None:
    """Wrap admet.compute_admet so an import-time failure (RDKit missing in
    a stripped-down environment) doesn't take the whole jobs router down —
    the frontend just sees admet=null and renders an em-dash for that
    compound's chip row."""
    try:
        from deltadock_pipeline.admet import compute_admet
        return compute_admet(smiles)
    except Exception:
        return None


def _pdb_quality_for(pdb_id: str, chain: str) -> dict | None:
    """Look up the cached cross-docking sanity-check result for this
    (pdb_id, chain). Returns None if the background job hasn't run yet
    (catalog targets eventually get pre-baked; custom uploads compute on
    first job submission)."""
    # Preserve USR_ case (uploads); uppercase RCSB IDs.
    pid = pdb_id if pdb_id.startswith("USR_") else pdb_id.upper()
    ch = (chain or "A").upper()
    try:
        from deltadock_pipeline.crossdock import load_cached
        return load_cached(pid, ch)
    except Exception:
        return None


@router.post("", response_model=JobOut, status_code=201,
              dependencies=[Depends(JOBS_LIMIT)])
def create_job(
    payload: JobCreate,
    background: BackgroundTasks,
    session: Session = Depends(get_session),
) -> JobOut:
    # Schema validator already normalized the pdb_id (uppercase for RCSB IDs,
    # case-preserved for USR_ uploads). Re-uppercasing here would corrupt
    # USR_ tokens since the lookup-router stores files with lowercase hex —
    # any extra .upper() breaks the runner's file lookup.

    # Eager SMILES validation. Catches typos and garbage at submit time so the
    # user gets immediate field-level feedback instead of a 30-second wait
    # followed by a cryptic "ligand_prep_failed" cell. We use the pipeline's
    # resilient parser (the same one the runner uses) so anything that would
    # actually dock gets accepted, and anything truly broken gets rejected.
    invalid: list[dict] = []
    try:
        from deltadock_pipeline.prep import _parse_smiles_resilient
        for i, c in enumerate(payload.compounds):
            smi = (c.smiles or "").strip()
            if not smi:
                invalid.append({"index": i, "name": c.name, "reason": "empty SMILES"})
                continue
            if len(smi) > 1000:
                invalid.append({"index": i, "name": c.name, "reason": f"SMILES too long ({len(smi)} chars; max 1000)"})
                continue
            try:
                mol = _parse_smiles_resilient(smi)
            except Exception as e:
                invalid.append({"index": i, "name": c.name, "reason": f"parse error: {type(e).__name__}"})
                continue
            if mol is None:
                invalid.append({"index": i, "name": c.name, "reason": "RDKit could not parse SMILES (not a valid molecule)"})
    except ImportError:
        # If the pipeline isn't importable in this environment (dev without
        # bio deps), skip eager validation so we don't fail-closed in dev.
        pass

    if invalid:
        raise HTTPException(
            status_code=422,
            detail={
                "message": f"{len(invalid)} of {len(payload.compounds)} compound SMILES failed validation",
                "invalid_compounds": invalid,
            },
        )

    job = Job(
        pdb_id=payload.pdb_id,
        chain=payload.chain,
        uniprot_id=payload.uniprot_id,
        mutations=",".join(payload.mutations),
        exhaustiveness=payload.exhaustiveness,
        include_wt=payload.include_wt,
        status=JobStatus.PENDING,
    )
    session.add(job)
    session.commit()
    session.refresh(job)

    for c in payload.compounds:
        session.add(Compound(job_id=job.id, name=c.name, smiles=c.smiles))
    session.commit()
    session.refresh(job)

    # Phase 1: run inline in a background task. Phase 2: dispatch to Celery + RunPod.
    background.add_task(run_job_in_background, job.id)

    return _to_out(job)


@router.get("/{job_key}", response_model=JobOut)
def get_job(job_key: str, session: Session = Depends(get_session)) -> JobOut:
    """Fetch a job by either its share_id (preferred, public) or legacy
    integer primary key. The same path handles both for backward compat
    with any links that still exist in the wild."""
    job = _resolve_job(session, job_key)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return _to_out(job)


@router.post("/{job_key}/cancel", response_model=JobOut)
def cancel_job(job_key: str, session: Session = Depends(get_session)) -> JobOut:
    """Cancel a running or pending job.

    The runner cooperatively checks job.status between cells and bails out
    when it sees CANCELLED. The currently in-flight Pod GPU call (~3 s) will
    complete and any results-already-computed stay in the DB; no further
    cells dispatch, so we don't waste compute on a job the user no longer
    wants.

    Idempotent on terminal statuses: cancelling an already-completed or
    already-failed job is a no-op (returns 200 with the existing state).
    Cancelling an already-cancelled job is also a no-op.
    """
    job = _resolve_job(session, job_key)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
        # Terminal — nothing to cancel. Return current state without
        # mutating; this makes the endpoint safe to call from a Cancel
        # button that might race with normal completion.
        return _to_out(job)
    job.status = JobStatus.CANCELLED
    job.error_message = "Cancelled by user"
    job.updated_at = datetime.utcnow()
    session.add(job)
    session.commit()
    session.refresh(job)
    return _to_out(job)


@router.get("", response_model=list[JobOut])
def list_jobs(
    limit: int = Query(20, ge=1, le=200, description="Max jobs to return (1-200)"),
    offset: int = Query(0, ge=0, description="Skip this many jobs (for pagination)"),
    session: Session = Depends(get_session),
) -> list[JobOut]:
    stmt = (
        select(Job)
        .order_by(Job.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    return [_to_out(j) for j in session.exec(stmt)]


@router.get("/{job_key}/poses/{compound_id}/{variant}", response_class=PlainTextResponse)
def get_pose(
    job_key: str,
    compound_id: int,
    variant: str,
    session: Session = Depends(get_session),
) -> str:
    """Serve the docked-pose for a (job, compound, variant), best mode only.

    Vina output is PDBQT with all 9 modes concatenated. We extract mode 1 and
    convert to PDB via Open Babel so 3Dmol's parser handles every atom — its
    PDBQT support is incomplete and silently drops atoms with non-PDB columns.
    """
    import shutil as _shutil
    import subprocess as _subprocess
    import tempfile as _tempfile

    # Validate variant format up front — URL params are user-controlled and
    # we use them in DB filters + (indirectly) in path resolution below.
    if not _VARIANT_RE.match(variant):
        raise HTTPException(status_code=400, detail="invalid variant format")

    # Resolve job_key (share_id or legacy int) → integer id for the FK lookup.
    # DockingResult is keyed on the integer primary key, never on share_id.
    job = _resolve_job(session, job_key)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    job_id = job.id

    stmt = (
        select(DockingResult)
        .where(DockingResult.job_id == job_id)
        .where(DockingResult.compound_id == compound_id)
        .where(DockingResult.variant == variant)
    )
    result = session.exec(stmt).first()
    if not result or not result.pose_uri:
        raise HTTPException(status_code=404, detail="Pose not found")

    # Read through the storage abstraction so r2:// URIs and legacy filesystem
    # paths both resolve. The store enforces the path-traversal guard that
    # the original endpoint had (anything outside POSE_CACHE / R2 bucket is
    # rejected) so we don't have to repeat that check here.
    from ..services.pose_store import get_pose_store
    try:
        raw = get_pose_store().read(result.pose_uri)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Pose not found")
    except Exception:
        raise HTTPException(status_code=410, detail="Pose file no longer cached")
    if not raw:
        raise HTTPException(status_code=410, detail="Pose file no longer cached")
    text = raw.decode("utf-8", errors="replace")
    # Extract first MODEL block (best-scoring pose)
    if "MODEL" in text:
        out_lines = []
        in_first = False
        for line in text.splitlines(keepends=True):
            if line.startswith("MODEL"):
                if in_first:
                    break
                in_first = True
                continue
            if line.startswith("ENDMDL"):
                if in_first:
                    break
                continue
            if in_first:
                out_lines.append(line)
        best_pdbqt = "".join(out_lines)
    else:
        best_pdbqt = text

    # Convert PDBQT → PDB so 3Dmol parses every atom (its PDBQT mode is buggy).
    # Falls back to raw PDBQT if obabel isn't available.
    if not _shutil.which("obabel"):
        return best_pdbqt
    with _tempfile.TemporaryDirectory() as td:
        in_path = Path(td) / "pose.pdbqt"
        out_path = Path(td) / "pose.pdb"
        in_path.write_text(best_pdbqt)
        res = _subprocess.run(
            ["obabel", str(in_path), "-O", str(out_path)],
            capture_output=True, text=True, check=False,
        )
        if res.returncode == 0 and out_path.exists() and out_path.stat().st_size > 0:
            return out_path.read_text()
        return best_pdbqt
